import { assets } from '../../assets/assets';  // <-- FIXED PATH
import './Navbar.css';
import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <div className="navbar">
      <div className="navbar-left">
        <Link to="/home">
          <img src={assets.logo} alt="Logo" className="navbar-logo" />
        </Link>
      </div>

      <div className="navbar-center">
        <ul className="navbar-menu">
          <li><Link to="/home">Home</Link></li>
          <li><Link to="/products">Products</Link></li>
          <li><Link to="/about">About</Link></li>
        </ul>
      </div>

      <div className="navbar-right">
        <img src={assets.parcel_icon} alt="Orders" className="navbar-icon" />
        <img src={assets.profile_icon} alt="Profile" className="navbar-icon" />
      </div>
    </div>
  );
};

export default Navbar;
