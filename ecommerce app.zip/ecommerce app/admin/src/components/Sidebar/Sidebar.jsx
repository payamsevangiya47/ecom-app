import './Sidebar.css';
import { assets } from '../../assets/assets';
import { NavLink } from 'react-router-dom';

const Sidebar = () => (
  <aside className="sidebar">
    <img src={assets.parcel_icon} alt="Parcel Icon" className="sidebar-logo" />

    <NavLink 
      to="/add" 
      className={({ isActive }) => (isActive ? 'active' : '')}
    >
      Add Items
    </NavLink>

    <NavLink 
      to="/list" 
      className={({ isActive }) => (isActive ? 'active' : '')}
    >
      List Items
    </NavLink>

    <NavLink 
      to="/orders" 
      className={({ isActive }) => (isActive ? 'active' : '')}
    >
      Orders
    </NavLink>
  </aside>
);

export default Sidebar;
