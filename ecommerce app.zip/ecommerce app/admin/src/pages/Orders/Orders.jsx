import { useEffect, useState } from "react";
import "./Orders.css";
import { toast } from "react-toastify";
import axios from "axios";

const url = "https://food-delivery-backend-au4q.onrender.com";

const Orders = () => {
  const [orders, setOrders] = useState([]);

  const fetchAllOrders = async () => {
    try {
      const response = await axios.get(`${url}/api/order/list`);
      if (response.data.success) {
        setOrders(response.data.data.reverse());
      } else {
        toast.error("Error");
      }
    } catch (err) {
      toast.error("Error");
    }
  };

  // Use this function as the onChange handler for each order status select dropdown
  const statusHandler = async (event, orderId) => {
    try {
      const response = await axios.post(`${url}/api/order/status`, { orderId, status: event.target.value });
      if (response.data.success) {
        await fetchAllOrders();
      }
    } catch (err) {
      toast.error("Error updating order status!");
    }
  };

  useEffect(() => {
    fetchAllOrders();
  }, []);

  return (
    <div className="orders-container">
      {orders.map(order => (
        <div key={order._id} className="order-item">
          <div>
            <strong>Name:</strong> {order.address.firstName} {order.address.lastName}
          </div>
          <div>
            <strong>Address:</strong> {order.address.street}, {order.address.city}, {order.address.state}, {order.address.country}, {order.address.zipcode}
          </div>
          <div>
            <strong>Phone:</strong> {order.address.phone}
          </div>
          <div>
            <strong>Items:</strong> {order.items.length}
          </div>
          <div>
            <strong>Amount:</strong> ₹{order.amount}
          </div>
          <div>
            <strong>Status:</strong>
            <select
              value={order.status}
              onChange={event => statusHandler(event, order._id)}
            >
              <option value="Pending">Pending</option>
              <option value="Accepted">Accepted</option>
              <option value="Delivered">Delivered</option>
              <option value="Cancelled">Cancelled</option>
            </select>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Orders;
