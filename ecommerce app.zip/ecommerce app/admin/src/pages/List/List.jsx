import { useEffect, useState } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import "./List.css";

const url = "https://food-delivery-backend-au4q.onrender.com";

const List = () => {
  const [list, setList] = useState([]);

  const fetchList = async () => {
    try {
      const response = await axios.get(`${url}/api/food/list`);
      if (response.data.success) {
        setList(response.data.data);
      } else {
        toast.error("Error");
      }
    } catch (err) {
      toast.error("Error");
    }
  };

  const removeFood = async (foodId) => {
    try {
      const response = await axios.post(`${url}/api/food/remove`, { id: foodId });
      await fetchList();
      if (response.data.success) {
        toast.success(response.data.message);
      } else {
        toast.error("Error");
      }
    } catch (err) {
      toast.error("Error");
    }
  };

  useEffect(() => {
    fetchList();
  }, []);

  return (
    <div className="list-container">
      <h2>All Product List</h2>
      {list.map(item => (
        <div key={item.id} className="list-item">
          <span>{item.name}</span>
          <span>{item.category}</span>
          <span>{item.price}</span>
          <button onClick={() => removeFood(item.id)}>Delete</button>
        </div>
      ))}
    </div>
  );
};

export default List;
