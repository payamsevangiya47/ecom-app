import jwt from "jsonwebtoken";
import dotenv from "dotenv";
dotenv.config();

/**
 * Middleware to verify JWT token sent in Authorization header.
 * If valid, attaches decoded user info to req.user and calls next().
 * Otherwise, returns 401 Unauthorized error.
 */
export const verifyToken = (req, res, next) => {
  try {
    // Get token from the header (Authorization: Bearer <token>)
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ success: false, message: "Unauthorized: No token provided." });
    }

    // Bearer token format: "Bearer <token>"
    const token = authHeader.split(" ")[1];
    if (!token) {
      return res.status(401).json({ success: false, message: "Unauthorized: Malformed token." });
    }

    // Verify token
    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
      if (err) {
        return res.status(403).json({ success: false, message: "Token is invalid or expired." });
      }
      // Attach user info to request object
      req.user = user;
      next();
    });
  } catch (error) {
    console.error("Auth middleware error:", error);
    res.status(500).json({ success: false, message: "Server error in authentication." });
  }
};
