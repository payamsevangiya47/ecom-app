import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },                // Full name
    email: { type: String, required: true, unique: true }, // Email for login
    password: { type: String, required: true },            // Hashed password
    cartData: { type: Object, default: {} },               // Cart: productId to quantity map
    role: { type: String, default: "user" },               // User role, e.g., user/admin
    addresses: [                                            // Optional array of saved addresses
      {
        firstName: String,
        lastName: String,
        street: String,
        city: String,
        state: String,
        country: String,
        zipcode: String,
        phone: String
      }
    ],
    orderHistory: [
      { type: mongoose.Schema.Types.ObjectId, ref: "order" }
    ]
  },
  { timestamps: true }
);

const userModel = mongoose.models.user || mongoose.model("user", userSchema);

export default userModel;
