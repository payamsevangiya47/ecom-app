import mongoose from "mongoose";

const foodSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },            // Product name
    description: { type: String, required: true },     // Product description
    price: { type: Number, required: true },           // Price of product
    category: { type: String, required: true },        // Category of product
    image: { type: String, required: true },           // Image URL or path
    stock: { type: Number, default: 0 },               // Stock quantity
    sku: { type: String, unique: true, sparse: true }  // Optional SKU for tracking
  },
  { timestamps: true }
);

const foodModel = mongoose.models.food || mongoose.model("food", foodSchema);

export default foodModel;
