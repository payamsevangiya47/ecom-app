import mongoose from "mongoose";

const orderSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "user", required: true },
    items: [
      {
        foodId: { type: mongoose.Schema.Types.ObjectId, ref: "food" },
        quantity: { type: Number, default: 1, required: true }
      }
    ],
    amount: { type: Number, required: true },           // Total amount for the order
    status: { type: String, default: "Food Processing" }, // Status of the order
    address: {
      firstName: String,
      lastName: String,
      street: String,
      city: String,
      state: String,
      country: String,
      zipcode: String,
      phone: String
    }
  },
  { timestamps: true }
);

const orderModel = mongoose.models.order || mongoose.model("order", orderSchema);

export default orderModel;
