import express from 'express';
import { verifyToken } from '../middleware/auth.js'; // FIXED: Use named import
import { listOrders, placeOrder, updateStatus, userOrders, verifyOrder } from '../controllers/orderController.js';

const orderRouter = express.Router();

orderRouter.get("/list", listOrders);
orderRouter.post("/userorders", verifyToken, userOrders); // updated
orderRouter.post("/place", verifyToken, placeOrder);      // updated
orderRouter.post("/status", updateStatus);
orderRouter.post("/verify", verifyOrder);

export default orderRouter;
