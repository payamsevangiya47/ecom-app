import express from "express";
import {
  addToCart,
  getCart,
  updateCartItem,
  removeCartItem,
} from "../controllers/cartController.js";
import { verifyToken } from "../middleware/auth.js";

const router = express.Router();

// Add an item to cart (protected, requires authentication)
router.post("/add", verifyToken, addToCart);

// Get user's current cart (protected)
router.get("/get", verifyToken, getCart);

// Update a specific cart item quantity (protected)
router.put("/update/:itemId", verifyToken, updateCartItem);

// Remove a specific item from cart (protected)
router.delete("/remove/:itemId", verifyToken, removeCartItem);

// Default export (required!)
export default router;
