import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import connectDB from "./config/db.js";

import foodRoute from "./routes/foodRoute.js";
import orderRoute from "./routes/orderRoute.js";
import userRoute from "./routes/userRoute.js";
import cartRoute from "./routes/cartRoute.js";

dotenv.config();

const app = express();

// Connect to MongoDB
connectDB();

// CORS configuration - allow your frontend origin for dev
const corsOptions = {
  origin: "http://localhost:5174", // or your production frontend URL
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"],
  credentials: true,
};

app.use(cors(corsOptions));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// API routes
app.use("/api/food", foodRoute);
app.use("/api/order", orderRoute);
app.use("/api/user", userRoute);
app.use("/api/cart", cartRoute);

const PORT = process.env.PORT || 4000;

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
