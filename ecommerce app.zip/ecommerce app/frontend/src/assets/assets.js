// Import images/icons
import basket_icon from './basket_icon.png';
import logo from './logo.png';
import logo2 from './logo2.png';
import search_icon from './search_icon.png';
import add_icon_green from './add_icon_green.png';
import add_icon_white from './add_icon_white.png';
import app_store from './app_store.png';
import bag_icon from './bag_icon.png';
import cross_icon from './cross_icon.png';
import facebook_icon from './facebook_icon.png';
import linkedin_icon from './linkedin_icon.png';
import logout_icon from './logout_icon.png';
import parcel_icon from './parcel_icon.png';
import play_store from './play_store.png';
import profile_icon from './profile_icon.png';
import rating_starts from './rating_starts.png';
import remove_icon_red from './remove_icon_red.png';
import selector_icon from './selector_icon.png';
import twitter_icon from './twitter_icon.png';

// ✅ OPTIONAL FIX — add a fallback upload area image
// If you have an actual file named "upload_area.png", this will load it.
// If not, you can copy any existing image (e.g., add_icon_green) as placeholder.
import upload_area from './add_icon_green.png'; // change to './upload_area.png' if you have the file

// ✅ Export all assets in a single object
export const assets = {
  logo2,
  logo,
  basket_icon,
  search_icon,
  rating_starts,
  add_icon_green,
  add_icon_white,
  remove_icon_red,
  app_store,
  play_store,
  linkedin_icon,
  facebook_icon,
  twitter_icon,
  cross_icon,
  selector_icon,
  profile_icon,
  logout_icon,
  bag_icon,
  parcel_icon,
  upload_area // ✅ added this to prevent "uploadarea not found" error
};

// ✅ Menu list example (edit names/images as needed)
export const menu_list = [
  { menu_name: "Bag", menu_image: bag_icon },
  { menu_name: "Parcel", menu_image: parcel_icon }
];

// ✅ Example items (you can add more)
export const items = [
  {
    _id: "33",
    name: "Bag",
    image: bag_icon,
    price: 500,
    description: "Nice bag"
  }
];
